/*
* Vector.cpp
*
*  Created on: 22 janv. 2018
*      Author: rchamoulaud
*/
#include <math.h>
#include "Voxel.hpp"


Voxel::Voxel() {
	Voxel(*new Point(), 0);
}
Voxel::Voxel(Point p, double l) {
	this->centre = p;
	this->length = l;
	sommet[0] = *new Point(centre.getX() - length / 2.0, centre.getY() - length / 2.0, centre.getZ() - length / 2.0);
	sommet[1] = *new Point(centre.getX() + length / 2.0, centre.getY() - length / 2.0, centre.getZ() - length / 2.0);
	sommet[2] = *new Point(centre.getX() + length / 2.0, centre.getY() - length / 2.0, centre.getZ() + length / 2.0);
	sommet[3] = *new Point(centre.getX() - length / 2.0, centre.getY() - length / 2.0, centre.getZ() + length / 2.0);
	sommet[4] = *new Point(centre.getX() - length / 2.0, centre.getY() + length / 2.0, centre.getZ() - length / 2.0);
	sommet[5] = *new Point(centre.getX() + length / 2.0, centre.getY() + length / 2.0, centre.getZ() - length / 2.0);
	sommet[6] = *new Point(centre.getX() + length / 2.0, centre.getY() + length / 2.0, centre.getZ() + length / 2.0);
	sommet[7] = *new Point(centre.getX() - length / 2.0, centre.getY() + length / 2.0, centre.getZ() + length / 2.0);
}
double Voxel::getX() {
	return this->centre.getX();
}
double Voxel::getY() {
	return this->centre.getY();
}
Point* Voxel::getSommet() {
	return this->sommet;
}
double Voxel::getZ() {
	return this->centre.getZ();
}
Point Voxel::getCentre() {
	return this->centre;
}
double Voxel::getLength() {
	return this->length;
}
Voxel* Voxel::octree() {
	Voxel* decompose = new Voxel[8];
	decompose[0] = *new Voxel(*new Point(centre.getX() - length / 4.0, centre.getY() - length / 4.0, centre.getZ() - length / 4.0), length / 2.0);
	decompose[1] = *new Voxel(*new Point(centre.getX() + length / 4.0, centre.getY() - length / 4.0, centre.getZ() - length / 4.0), length / 2.0);
	decompose[2] = *new Voxel(*new Point(centre.getX() + length / 4.0, centre.getY() - length / 4.0, centre.getZ() + length / 4.0), length / 2.0);
	decompose[3] = *new Voxel(*new Point(centre.getX() - length / 4.0, centre.getY() - length / 4.0, centre.getZ() + length / 4.0), length / 2.0);
	decompose[4] = *new Voxel(*new Point(centre.getX() - length / 4.0, centre.getY() + length / 4.0, centre.getZ() - length / 4.0), length / 2.0);
	decompose[5] = *new Voxel(*new Point(centre.getX() + length / 4.0, centre.getY() + length / 4.0, centre.getZ() - length / 4.0), length / 2.0);
	decompose[6] = *new Voxel(*new Point(centre.getX() + length / 4.0, centre.getY() + length / 4.0, centre.getZ() + length / 4.0), length / 2.0);
	decompose[7] = *new Voxel(*new Point(centre.getX() - length / 4.0, centre.getY() + length / 4.0, centre.getZ() + length / 4.0), length / 2.0);
	return decompose;
}
void Voxel::drawEdge() {
	glColor3f(1, 0, 0);
	glBegin(GL_LINES);
	glVertex3f(sommet[0].getX(), sommet[0].getY(), sommet[0].getZ());
	glVertex3f(sommet[1].getX(), sommet[1].getY(), sommet[1].getZ());

	glVertex3f(sommet[0].getX(), sommet[0].getY(), sommet[0].getZ());
	glVertex3f(sommet[4].getX(), sommet[4].getY(), sommet[4].getZ());

	glVertex3f(sommet[0].getX(), sommet[0].getY(), sommet[0].getZ());
	glVertex3f(sommet[3].getX(), sommet[3].getY(), sommet[3].getZ());

	glVertex3f(sommet[7].getX(), sommet[7].getY(), sommet[7].getZ());
	glVertex3f(sommet[3].getX(), sommet[3].getY(), sommet[3].getZ());

	glVertex3f(sommet[7].getX(), sommet[7].getY(), sommet[7].getZ());
	glVertex3f(sommet[4].getX(), sommet[4].getY(), sommet[4].getZ());

	glVertex3f(sommet[7].getX(), sommet[7].getY(), sommet[7].getZ());
	glVertex3f(sommet[6].getX(), sommet[6].getY(), sommet[6].getZ());

	glVertex3f(sommet[5].getX(), sommet[5].getY(), sommet[5].getZ());
	glVertex3f(sommet[4].getX(), sommet[4].getY(), sommet[4].getZ());

	glVertex3f(sommet[5].getX(), sommet[5].getY(), sommet[5].getZ());
	glVertex3f(sommet[6].getX(), sommet[6].getY(), sommet[6].getZ());

	glVertex3f(sommet[5].getX(), sommet[5].getY(), sommet[5].getZ());
	glVertex3f(sommet[1].getX(), sommet[1].getY(), sommet[1].getZ());

	glVertex3f(sommet[2].getX(), sommet[2].getY(), sommet[2].getZ());
	glVertex3f(sommet[3].getX(), sommet[3].getY(), sommet[3].getZ());

	glVertex3f(sommet[2].getX(), sommet[2].getY(), sommet[2].getZ());
	glVertex3f(sommet[6].getX(), sommet[6].getY(), sommet[6].getZ());

	glVertex3f(sommet[2].getX(), sommet[2].getY(), sommet[2].getZ());
	glVertex3f(sommet[1].getX(), sommet[1].getY(), sommet[1].getZ());
	glEnd();

}
void Voxel::renderVoxel() {
	Point* voxel = new Point[8];
	voxel[0] = *new Point(centre.getX() - length / 2.0, centre.getY() - length / 2.0, centre.getZ() - length / 2.0);
	voxel[1] = *new Point(centre.getX() - length / 2.0, centre.getY() - length / 2.0, centre.getZ() + length / 2.0);
	voxel[2] = *new Point(centre.getX() + length / 2.0, centre.getY() - length / 2.0, centre.getZ() + length / 2.0);
	voxel[3] = *new Point(centre.getX() + length / 2.0, centre.getY() - length / 2.0, centre.getZ() - length / 2.0);

	voxel[4] = *new Point(centre.getX() - length / 2.0, centre.getY() + length / 2.0, centre.getZ() - length / 2.0);
	voxel[5] = *new Point(centre.getX() - length / 2.0, centre.getY() + length / 2.0, centre.getZ() + length / 2.0);
	voxel[6] = *new Point(centre.getX() + length / 2.0, centre.getY() + length / 2.0, centre.getZ() + length / 2.0);
	voxel[7] = *new Point(centre.getX() + length / 2.0, centre.getY() + length / 2.0, centre.getZ() - length / 2.0);

	int i = 0;
	//Face du bas
	glColor3f(1, 0, 0);
	glBegin(GL_QUADS);
	glVertex3f(voxel[i].getX(), voxel[i].getY(), voxel[i].getZ()); glVertex3f(voxel[i + 1].getX(), voxel[i + 1].getY(), voxel[i + 1].getZ()); glVertex3f(voxel[i + 2].getX(), voxel[i + 2].getY(), voxel[i + 2].getZ()); glVertex3f(voxel[i + 3].getX(), voxel[i + 3].getY(), voxel[i + 3].getZ());
	glEnd();

	i += 4;
	//Face du haut
	glColor3f(1, 1, 0);
	glBegin(GL_QUADS);
	glVertex3f(voxel[i].getX(), voxel[i].getY(), voxel[i].getZ()); glVertex3f(voxel[i + 1].getX(), voxel[i + 1].getY(), voxel[i + 1].getZ()); glVertex3f(voxel[i + 2].getX(), voxel[i + 2].getY(), voxel[i + 2].getZ()); glVertex3f(voxel[i + 3].getX(), voxel[i + 3].getY(), voxel[i + 3].getZ());
	glEnd();
	//Face de gauche
	glColor3f(1, 0, 1);
	glBegin(GL_QUADS);
	glVertex3f(voxel[0].getX(), voxel[0].getY(), voxel[0].getZ()); glVertex3f(voxel[1].getX(), voxel[1].getY(), voxel[1].getZ()); glVertex3f(voxel[5].getX(), voxel[5].getY(), voxel[5].getZ()); glVertex3f(voxel[4].getX(), voxel[4].getY(), voxel[4].getZ());
	glEnd();

	//Face de droite
	glColor3f(0, 1, 0);
	glBegin(GL_QUADS);
	glVertex3f(voxel[2].getX(), voxel[2].getY(), voxel[2].getZ()); glVertex3f(voxel[3].getX(), voxel[3].getY(), voxel[3].getZ()); glVertex3f(voxel[7].getX(), voxel[7].getY(), voxel[7].getZ()); glVertex3f(voxel[6].getX(), voxel[6].getY(), voxel[6].getZ());
	glEnd();

	//Face de devant
	glColor3f(0, 1, 1);
	glBegin(GL_QUADS);
	glVertex3f(voxel[1].getX(), voxel[1].getY(), voxel[1].getZ()); glVertex3f(voxel[2].getX(), voxel[2].getY(), voxel[2].getZ()); glVertex3f(voxel[6].getX(), voxel[6].getY(), voxel[6].getZ()); glVertex3f(voxel[5].getX(), voxel[5].getY(), voxel[5].getZ());
	glEnd();

	//Face de derriere
	glColor3f(0, 0, 1);
	glBegin(GL_QUADS);
	glVertex3f(voxel[0].getX(), voxel[0].getY(), voxel[0].getZ()); glVertex3f(voxel[3].getX(), voxel[3].getY(), voxel[3].getZ()); glVertex3f(voxel[7].getX(), voxel[7].getY(), voxel[7].getZ()); glVertex3f(voxel[4].getX(), voxel[4].getY(), voxel[4].getZ());
	glEnd();

	delete[] voxel;
}