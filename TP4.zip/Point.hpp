/*
 * Point.hpp
 *
 *  Created on: 22 janv. 2018
 *      Author: rchamoulaud
 */

#ifndef POINT_HPP_
#define POINT_HPP_

class Point;

#include "GL/glut.h"
#include "Vector.hpp"

class Point{
	private:
		double x,y,z;
	public:
		Point();
		Point(double x,double y,double z);
		Point(const Point& p);
		double getX();
		double getY();
		double getZ();
		void setX(double x);
		void setY(double y);
		void setZ(double z);
		double distance(Point p);
		Point* projectOnLine(Point p1, Point p2);
		Point* projectOnLine(Vector v, Point p);
		Point* projectOnPlan(Point pointOnPlane, Vector normalOfPlane);
		void DrawPoint();
};
#endif /* POINT_HPP_ */
