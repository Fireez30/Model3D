/*
* Vector.hpp
*
*  Created on: 22 janv. 2018
*      Author: rchamoulaud
*/

#ifndef VOXEL_HPP_
#define VOXEL_HPP_

#include "GL/glut.h"
#include "Point.hpp"

class Voxel {
private:
	Point centre;
	Point* sommet = new Point[8];
	double length;
public:
	Voxel();
	Voxel(Point p, double l);
	double getX();
	double getY();
	double getZ();
	Point* getSommet();
	Point getCentre();
	double getLength();
	void renderVoxel();
	void drawEdge();
	Voxel* octree();
};

#endif /* VECTOR_HPP_ */

