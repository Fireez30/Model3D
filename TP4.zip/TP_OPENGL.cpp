//Jeff Chastine
#include <Windows.h>
#include <GL\glew.h>
#include <GL\freeglut.h>
#include <iostream>
#include <math.h>

#include "Point.hpp"
#include "Vector.hpp"
#include "Voxel.hpp"

using namespace std;
// Définition de la taille de la fenêtre
#define WIDTH  1280

#define HEIGHT 720

// Définition de la couleur de la fenêtre
#define RED   0.7
#define GREEN 0.7
#define BLUE  0.7
#define ALPHA 1

#define _USE_MATH_DEFINES

// Touche echap (Esc) permet de sortir du programme
#define KEY_ESC 27


// Entêtes de fonctions
void init_scene();
void render_scene();
GLvoid initGL();
GLvoid window_display();
GLvoid window_reshape(GLsizei width, GLsizei height);
GLvoid window_key(unsigned char key, int x, int y);

double radian = 0, meridient = 8, parallele = 8;
bool dessine = true;
int main(int argc, char **argv)
{
	// initialisation  des paramètres de GLUT en fonction
	// des arguments sur la ligne de commande
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA);

	// définition et création de la fenêtre graphique, ainsi que son titre
	glutInitWindowSize(WIDTH, HEIGHT);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("Premier exemple : carré");

	// initialisation de OpenGL et de la scène
	initGL();
	init_scene();

	// choix des procédures de callback pour 
	// le tracé graphique
	glutDisplayFunc(&window_display);
	// le redimensionnement de la fenêtre
	glutReshapeFunc(&window_reshape);
	// la gestion des événements clavier
	glutKeyboardFunc(&window_key);

	// la boucle prinicipale de gestion des événements utilisateur
	glutMainLoop();
	return 1;
}

// initialisation du fond de la fenêtre graphique : noir opaque
GLvoid initGL()
{
	glClearColor(RED, GREEN, BLUE, ALPHA);
}

// Initialisation de la scene. Peut servir à stocker des variables de votre programme
// à initialiser
void init_scene()
{
}

// fonction de call-back pour l´affichage dans la fenêtre

GLvoid window_display()
{
	glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();

	// C'est l'endroit où l'on peut dessiner. On peut aussi faire appel
	// à une fonction (render_scene() ici) qui contient les informations 
	// que l'on veut dessiner
	render_scene();

	// trace la scène grapnique qui vient juste d'être définie
	glFlush();
}

// fonction de call-back pour le redimensionnement de la fenêtre

GLvoid window_reshape(GLsizei width, GLsizei height)
{
	glViewport(0, 0, width, height);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	// ici, vous verrez pendant le cours sur les projections qu'en modifiant les valeurs, il est
	// possible de changer la taille de l'objet dans la fenêtre. Augmentez ces valeurs si l'objet est 
	// de trop grosse taille par rapport à la fenêtre.
	glOrtho(-80.0, 80.0, -30.0, 30.0, -80.0, 80.0);

	// toutes les transformations suivantes s´appliquent au modèle de vue 
	glMatrixMode(GL_MODELVIEW);
}

// fonction de call-back pour la gestion des événements clavier

GLvoid window_key(unsigned char key, int x, int y)
{
	switch (key) {
	case KEY_ESC:
		exit(1);
		break;
	case '+':
		parallele++;
		meridient++;
		dessine = true;
		break;
	case '-':
		if (parallele > 2)
			parallele--;
		if (meridient > 3)
			meridient--;
		dessine = true;
		break;
	default:
		printf("La touche %d n´est pas active.\n", key);
		dessine = false;
		break;
	}
	//glutPostRedisplay();

}

double factorielle(int n) {
	if (n == 0) {
		return 1;
	}
	else {
		int resultat = 1;
		for (int i = 1; i <= n; i++) {
			resultat = resultat * i;
		}
		return resultat;
	}
}
double random() {
	return (double)(rand() % 255) / 255.0;
}
void DrawCylindre(Point tabPoint[], int nbMeridien) {
	for (int i = 0; i < nbMeridien; i++) {
		glColor3f(random(), 0, random());
		glBegin(GL_QUADS); 
		Point p = tabPoint[i * 2];
		glVertex3f(p.getX(), p.getY(), p.getZ());
		p = tabPoint[i * 2 + 1];
		glVertex3f(p.getX(), p.getY(), p.getZ());
		if (i != nbMeridien-1) {
			p = tabPoint[i * 2 + 3];
			glVertex3f(p.getX(), p.getY(), p.getZ());
			p = tabPoint[i * 2 + 2];
			glVertex3f(p.getX(), p.getY(), p.getZ());
		}
		else {
			p = tabPoint[1];
			glVertex3f(p.getX(), p.getY(), p.getZ());
			p = tabPoint[0];
			glVertex3f(p.getX(), p.getY(), p.getZ());
		}
		glEnd();
	}
	glColor3f(random(), 0, random());
	glBegin(GL_POLYGON);
	for (int i = 0; i < nbMeridien * 2; i += 2) {
		Point p = tabPoint[i];
		glVertex3f(p.getX(), p.getY(), p.getZ());
		printf("Point num %d : %f,%f,%f\n", i, p.getX(), p.getY(), p.getZ());
	}
	glEnd();
	glColor3f(random(), 0, random());
	glBegin(GL_POLYGON);
	for (int i = 1; i < nbMeridien * 2; i += 2) {
		Point p = tabPoint[i];
		glVertex3f(p.getX(), p.getY(), p.getZ());
		printf("Point num %d : %f,%f,%f\n", i, p.getX(), p.getY(), p.getZ());
	}
	glEnd();
	
}

void DrawCone(Point tabPoint[], Point sommet, int nbMeridien) {
	for (int i = 0; i < nbMeridien; i++) {
		glColor3f(random(), random(), random());
		glBegin(GL_TRIANGLES);
		Point p = tabPoint[i];
		glVertex3f(p.getX(), p.getY(), p.getZ());
		if (i != nbMeridien - 1) {
			p = tabPoint[i + 1];
			glVertex3f(p.getX(), p.getY(), p.getZ());
		}
		else {
			p = tabPoint[0];
			glVertex3f(p.getX(), p.getY(), p.getZ());
		}
		glVertex3f(sommet.getX(), sommet.getY(), sommet.getZ());
		glEnd();
	}
	glColor3f(random(), random(), random());
	glBegin(GL_POLYGON);
	for (int i = 0; i < nbMeridien; i++) {
		Point p = tabPoint[i];
		glVertex3f(p.getX(), p.getY(), p.getZ());
		if (i != nbMeridien - 1) {
			p = tabPoint[i + 1];
			glVertex3f(p.getX(), p.getY(), p.getZ());
		}
		else {
			p = tabPoint[0];
			glVertex3f(p.getX(), p.getY(), p.getZ());
		}
	}
	glEnd();
}
void DrawSphere(Point* tabPoint[], int nbMeridient, int nbParallele,int rayon) {
	for (int i = 0; i < nbParallele - 1; i++) {
		for (int j = 0; j < nbMeridient; j++) {
			glColor3f(i*1.0/nbParallele, 0.8*i*1.0 / nbParallele, 0.4- i * 1.0 / nbParallele);
			glBegin(GL_POLYGON);
			Point p = tabPoint[i][j];
			glVertex3f(p.getX(), p.getY(), p.getZ());
			p = tabPoint[i+1][j];
			glVertex3f(p.getX(), p.getY(), p.getZ());
			if (j < nbMeridient - 1) {
				p = tabPoint[i + 1][j + 1];
				glVertex3f(p.getX(), p.getY(), p.getZ());
				p = tabPoint[i][j + 1];
			}
			else {
				p = tabPoint[i + 1][0];
				glVertex3f(p.getX(), p.getY(), p.getZ());
				p = tabPoint[i][0];
			}
			glVertex3f(p.getX(), p.getY(), p.getZ());
			glEnd();
		}
	}
	for (int i = 0; i < nbMeridient; i++) {
		glColor3f(0, 0, 0.4);
		glBegin(GL_TRIANGLES);
		Point p = *new Point(0, rayon, 0);
		glVertex3f(p.getX(), p.getY(), p.getZ());
		p = tabPoint[0][i];

		glVertex3f(p.getX(), p.getY(), p.getZ());
		if (i<nbMeridient - 1)
			p = tabPoint[0][i+1];
		else
			p = tabPoint[0][0];

		glVertex3f(p.getX(), p.getY(), p.getZ());
		glEnd();
		glColor3f(1, 0.8, 0);
		glBegin(GL_TRIANGLES);
		p = *new Point(0, -1*rayon, 0);
		glVertex3f(p.getX(), p.getY(), p.getZ());
		p = tabPoint[nbParallele - 1][i];
		glVertex3f(p.getX(), p.getY(), p.getZ());
		if (i<nbMeridient - 1)
			p = tabPoint[nbParallele-1][i+1];
		else
			p = tabPoint[nbParallele - 1][0];
		glVertex3f(p.getX(), p.getY(), p.getZ());
		glEnd();
	}
	for (int i = 0; i < nbMeridient; i++) {
		glColor3f(1, 0, 0);
		glBegin(GL_LINE_STRIP);
		glVertex3f(0, rayon, 0);
		for (int j = 0; j < nbParallele; j++) {
			Point p = tabPoint[j][i];
			glVertex3f(p.getX(), p.getY(), p.getZ());
		}
		glVertex3f(0, -rayon, 0);
		glEnd();
	}
}

Point** calculeSphere(double rayon, int nbMeridient, int nbParallele) {
	Point** tab = new Point*[nbParallele];
	nbParallele++;
	for (int i = 0; i < nbParallele; i++) {
		tab[i] = new Point[nbMeridient];
	}
	const double PI = atan(1) * 4;
	double angleBase = 0, angleHauteur = PI / (double)(nbParallele);
	for (int i = 0; i < nbParallele; i++) {
		angleBase = 0;
		for (int j = 0; j < nbMeridient; j++) {
			double x = rayon * sin(angleHauteur) * cos(angleBase);
			double y = rayon * cos(angleHauteur);
			double z = rayon * sin(angleHauteur) * sin(angleBase);
			tab[i][j] = *new Point(x, y, z);
			glVertex3f(x, y, z);
			angleBase += 2.0 * PI / (double)(nbMeridient);
		}
		angleHauteur += PI / (double)nbParallele;
	}
	return tab;
}
int voxelInsideSphere(Point centre, double length, Voxel v) {
	boolean inside = v.getCentre().distance(centre) <= length, insideTemp = inside;
	Point* sommets = v.getSommet();
	for (int i = 0; i < 8; i++) {
		inside = sommets[i].distance(centre) <= length;

		if (inside != insideTemp) {
			return 0;	//Intersection avec le cercle
		}
	}
	if (inside == true) {
		return 1;	//Voxel entièrement dans le cercle
	}
	return -1;	//Voxel pas du tout dans le cercle
}
void computeSphere(Point centre, double length, Voxel v, int res, int i) {
	if (res > i) {
		int inside = voxelInsideSphere(centre, length, v);
		if (inside == 1) {
			v.renderVoxel();
		}
		else if (inside == 0) {
			Voxel* aTraite = v.octree();
			for (int j = 0; j < 8; j++) {
				computeSphere(centre, length, aTraite[j], res, i + 1);
			}
		}
	}
}
void displaySphere(Point centre, double length, int res) {
	Voxel v = *new Voxel(centre, 2 * length);

	computeSphere(centre, length, v, res, 0);

	v.drawEdge();
}

int voxelInsideCylinder(Point centre, Vector axe, double rayon, Voxel v) {
	Point centreTemp = *new Point(centre.getX(), 0, centre.getZ());
	Point pTemp = *new Point(v.getX(), 0, v.getZ());
	Point pTemp2 = *centre.projectOnLine(axe, v.getCentre());
	boolean inside = centre.distance(pTemp2) <= rayon &&
					 centreTemp.distance(pTemp) <= axe.norme()/2.0;
	double insideTemp = inside;
	Point* sommets = v.getSommet();
	for (int i = 0; i < 8; i++) {
		pTemp = *new Point(sommets[i].getX(), 0, sommets[i].getZ());
		pTemp2 = *centre.projectOnLine(axe, sommets[i]);
		inside =centre.distance(pTemp2) <= rayon &&
			centreTemp.distance(pTemp) <= axe.norme() / 2.0;

		if (inside != insideTemp) {
			return 0;	//Intersection avec le cercle
		}
	}
	if (inside == true) {
		return 1;	//Voxel entièrement dans le cercle
	}
	return -1;	//Voxel pas du tout dans le cercle
}
void computeCylinder(Point centre, Vector axe, double rayon, Voxel v, int res, int i) {
	if (res > i) {
		int inside = voxelInsideCylinder(centre, axe,rayon , v);
		if (inside == 1) {
			v.renderVoxel();
		}
		else if (inside == 0) {
			Voxel* aTraite = v.octree();
			for (int j = 0; j < 8; j++) {
				computeCylinder(centre, axe, rayon, aTraite[j], res, i + 1);
			}
		}
	}
}
void displayCylinder(Point centre, Vector axe,double rayon, int res) {
	Voxel v;
	if (axe.norme() > 2*rayon) {
		v = *new Voxel(centre, axe.norme());
	}
	else {
		v = *new Voxel(centre, 2 * rayon);
	}
	computeCylinder(centre, axe, rayon, v, res, 0);

	v.drawEdge();
}
void computeIntersect(Point centreS, double rS, Point centreC, Vector axeC, double rC, Voxel v, int res, int i) {
	if (res > i) {
		int insideS = voxelInsideSphere(centreS, rS, v);
		int insideC = voxelInsideCylinder(centreC, axeC, rC, v);
		if (insideS == 1 && insideC == 1) {
			v.renderVoxel();
		}
		else if ((insideS == 0 && insideC != -1) || (insideC == 0 && insideS != -1)) {
			Voxel* aTraite = v.octree();
			for (int j = 0; j < 8; j++) {
				computeIntersect(centreS, rS, centreC, axeC, rC, aTraite[j], res, i + 1);
			}
		}
	}
}
void DisplayIntersectSphereCylinder(Point centreS, double rS, Point centreC, Vector axeC, double rC, int res) {
	Voxel v;
	if (axeC.norme() > 2 * rC) {
		v = *new Voxel(centreC, axeC.norme());
	}
	else {
		v = *new Voxel(centreC, 2 * rC);
	}
	computeIntersect(centreS, rS, centreC, axeC, rC, v, res, 0);
	v.drawEdge();
}
void computeSoustraction(Point centreS, double rS, Point centreC, Vector axeC, double rC, Voxel v, int res, int i) {
	if (res > i) {
		int insideS = voxelInsideSphere(centreS, rS, v);
		int insideC = voxelInsideCylinder(centreC, axeC, rC, v);
		if (insideS == 1 && insideC == 1) {
			Voxel* aTraite = v.octree();
			for (int j = 0; j < 8; j++) {
				computeSoustraction(centreS, rS, centreC, axeC, rC, aTraite[j], res, i + 1);
			}
		}
		else if (insideS == 0 || insideC == 0) {
			Voxel* aTraite = v.octree();
			for (int j = 0; j < 8; j++) {
				computeSoustraction(centreS, rS, centreC, axeC, rC, aTraite[j], res, i + 1);
			}
		}
		else if ((insideS == 1 && insideC != 1) || (insideC == 1 && insideS != 1))
			v.renderVoxel();
	}
}
void DisplaySoustractionSphereCylinder(Point centreS, double rS, Point centreC, Vector axeC, double rC, int res) {
	Voxel v;
	if (axeC.norme() > 2 * rC) {
		v = *new Voxel(centreC, axeC.norme() + rS * 2);
	}
	else {
		v = *new Voxel(centreC, 2 * rC + rS * 2);
	}
	computeSoustraction(centreS, rS, centreC, axeC, rC, v, res, 0);
	v.drawEdge();
}
void DisplayAdditionSphereCylinder(Point centreS, double rS, Point centreC, Vector axeC, double rC, int res) {
	Voxel v;
	if (axeC.norme() > 2 * rC) {
		v = *new Voxel(centreC, axeC.norme());
	}
	else {
		v = *new Voxel(centreC, 2 * rC);
	}
	computeCylinder(centreC, axeC, rC, v, res, 0);
	v = *new Voxel(centreS, 2 * rS);
	computeSphere(centreS, rS, v, res, 0);
	v.drawEdge();
}
void render_scene()
{
	glEnable(GL_DEPTH_TEST);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	int rayon = 15;
	gluLookAt((rayon + 5)*0.25, 3, (rayon + 5)*0.25, 0, 0, 0, 0, 1, 0);
	/*
	=========TP4=========
	
	Vector corps = *new Vector(0, 20, 0);
	Point base = *new Point(0, 0, 20);
	int nbMeridient=10;
	double angle = 0;
	
	Point* cylindre = new Point[nbMeridient * 2];
	for (int i = 0; i < nbMeridient; i++) {
		double rad = PI * angle / 180.0;
		cylindre[i * 2] = *new Point(rayon*cos(rad), 0, rayon*sin(rad)+20);
		cylindre[i * 2 + 1] = *new Point(rayon*cos(rad), corps.getY() + base.getY(), rayon*sin(rad)+20);
		angle += 360.0 / (double)nbMeridient;
	}
	//DrawCylindre(cylindre, nbMeridient);

	Point* cone = new Point[nbMeridient];
	angle = 0;
	for (int i = 0; i < nbMeridient; i++) {
		double rad = PI * angle / 180.0;
		cone[i] = *new Point(rayon*cos(rad), 0, rayon*sin(rad)-20);
		angle += 360.0 / (double)nbMeridient;
	}
	Point sommet = *new Point(base);
	sommet.setY(20);
	sommet.setZ(-20);
	//DrawCone(cone, sommet,nbMeridient);
	Point** sphere = calculeSphere(15, meridient, parallele);
	DrawSphere(sphere, meridient, parallele,15);
	*/
	/*=========TP5=========*/
	//displaySphere(*new Point(), 20,5);
	//displayCylinder(*new Point(), *new Vector(0, 20, 0), 10, 6);
	//DisplayIntersectSphereCylinder(*new Point(10, 0, 0), 13, *new Point(), *new Vector(0, 20, 0), 10, 6);
	DisplaySoustractionSphereCylinder(*new Point(10, 0, 0), 13, *new Point(), *new Vector(0, 20, 0), 10, 7);
	//DisplayAdditionSphereCylinder(*new Point(10, 0, 0), 13, *new Point(), *new Vector(0, 20, 0), 10, 6);
}