/*
 * Point.cpp
 *
 *  Created on: 22 janv. 2018
 *      Author: rchamoulaud
 */

#include "Point.hpp"
#include <stdio.h> 
#include<math.h>

Point::Point(){
	x = 0;
	y = 0;
	z = 0;
}
Point::Point(double x,double y,double z){
	this->x=x;
	this->y=y;
	this->z=z;
}
Point::Point(const Point& p){
	this->x=p.x;
	this->y=p.y;
	this->z=p.z;
}
double Point::getX(){
	return this->x;
}
double Point::getY(){
	return this->y;
}
double Point::getZ(){
	return this->z;
}
void Point::setX(double x){
	this->x=x;
}
void Point::setY(double y){
	this->y=y;
}
void Point::setZ(double z){
	this->z=z;
}
double Point::distance(Point p) {
	return sqrt(pow(p.getX() - x, 2.0) + pow(p.getY() - y, 2.0) + pow(p.getZ() - z, 2.0));
}
Point* Point::projectOnLine(Point p1, Point p2){
	Vector* v2 = new Vector(p2.getX()-p1.getX(),p2.getY()-p1.getY(),p2.getZ()-p1.getZ());
	return projectOnLine(*v2,*this);
}
Point* Point::projectOnPlan(Point p, Vector v){
	Vector* v1 = new Vector(x-p.getX(),y-p.getY(),z-p.getZ());
		double norme = v1->scalar(v)/v.norme();
		return new Point(p.getX() - v.getX()*norme,
							 p.getY() - v.getY()*norme,
							 p.getZ() - v.getZ()*norme);
}
Point* Point::projectOnLine(Vector v, Point p){
	Vector* v1 = new Vector(x-p.getX(),y-p.getY(),z-p.getZ());
	v.normalize();
	double norme = v1->scalar(v)/v.norme();
	double x_= p.getX() + v.getX()*norme;
	double y_= p.getY() + v.getY()*norme;
	double z_= p.getZ() + v.getZ()*norme;
	return new Point(p.getX() + v.getX()*norme,
						 p.getY() + v.getY()*norme,
						 p.getZ() + v.getZ()*norme);
}

void Point::DrawPoint(){
	glBegin(GL_POINTS);
	glVertex3f(x,y,z);
	glEnd();
}