/*
 * Vector.hpp
 *
 *  Created on: 22 janv. 2018
 *      Author: rchamoulaud
 */

#ifndef VECTOR_HPP_
#define VECTOR_HPP_

class Vector;

#include "GL/glut.h"
#include "Point.hpp"

class Vector{
	private:
		double x,y,z;
	public:
		Vector();
		Vector(double x,double y,double z);
		Vector(const Vector& p);
		double getX();
		double getY();
		double getZ();
		void setX(double x);
		void setY(double y);
		void setZ(double z);
		double norme();
		void normalize();
		double scalar(Vector vector2);
		Vector* vectoriel(Vector vector2);
		double angle(Vector vector2);
		void drawLine(Point p);
};

#endif /* VECTOR_HPP_ */

