/*
 * Vector.cpp
 *
 *  Created on: 22 janv. 2018
 *      Author: rchamoulaud
 */
#include <math.h>
#include "Vector.hpp"


Vector::Vector(){
	x = 0;
	y = 0;
	z = 0;
}
Vector::Vector(double x,double y,double z){
	this->x=x;
	this->y=y;
	this->z=z;
}
Vector::Vector(const Vector& p){
	this->x=p.x;
	this->y=p.y;
	this->z=p.z;
}
double Vector::getX(){
	return this->x;
}
double Vector::getY(){
	return this->y;
}
double Vector::getZ(){
	return this->z;
}
void Vector::setX(double x){
	this->x=x;
}
void Vector::setY(double y){
	this->y=y;
}
void Vector::setZ(double z){
	this->z=z;
}
double Vector::norme(){
	return sqrt(x*x+y*y+z*z);
}
void Vector::normalize(){
	double norme = this->norme();
	x=x/norme;
	y=y/norme;
	z=z/norme;
}
double Vector::scalar(Vector vector2){
	return x*vector2.getX()+y*vector2.getY()+z*vector2.getZ();
}
Vector* Vector::vectoriel(Vector vector2){
	return new Vector(y*vector2.getZ() - z*vector2.getY(),
					  z*vector2.getX() - x*vector2.getZ(),
					  x*vector2.getY() - y*vector2.getX());
}
double Vector::angle(Vector vector2){
	double sc= this->scalar(vector2);
	return acos((sc/this->norme())/vector2.norme());
}
void Vector::drawLine(Point p){
	Point *p2 = new Point (p.getX()+x,p.getY()+y,p.getZ()+z);
	glBegin(GL_LINES);
		glVertex3f(p.getX(), p.getY(), p.getZ());
		glVertex3f(p2->getX(), p2->getY(), p2->getZ());
	glEnd();
}