#ifndef POINT_H
#define POINT_H

#include "Vector.h"
#include <string>
#include <sstream>


class Point {

private:

    double x;
    double y;
    double z;
    
public:

	Point();
	~Point();
	Point(double x,double y, double z);
	Point(Point *p);

	double getX();
	double getY();
	double getZ();
	void setX(double x);
	void setY(double y);
	void setZ(double z);
	Vector *createVector(Point *A, Point *B);
	Point *projectOnLine(Point *p1Line, Point *p2Line);
	Point* projectOnLine(Vector *v, Point *pLine);
	Point* projectOnLine(Point *pOnPlane, Vector *normalOfPlane);
	std::string print();
	int isInsideSphere(Point* ct, double ray) ;// return 0 if P inside Sphere, else return 1
};

#endif