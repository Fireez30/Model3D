#ifndef VECTOR_H
#define VECTOR_H

class Vector {

private:

    double x;
    double y;
    double z;

public:

	Vector();
	~Vector();
	Vector(double x,double y, double z);
	Vector(Vector *p);
	//Vector(Point p1, Point p2);
	double getX();
	double getY();
	double getZ();
	void setX(double x);
	void setY(double y);
	void setZ(double z);

	double norme();
	void normalize();
	double scalar(Vector *vector2);
	Vector Vectoriel( Vector *vector2);
	double Angle(Vector *vector2);
};

#endif