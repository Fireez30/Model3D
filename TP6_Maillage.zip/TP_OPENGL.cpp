///////////////////////////////////////////////////////////////////////////////
// Imagina
// ----------------------------------------------------------------------------
// IN - Synthèse d'images - Modélisation géométrique
// Auteur : Gilles Gesquière
// ----------------------------------------------------------------------------
// Base du TP 1
// programme permettant de créer des formes de bases.
// La forme représentée ici est un polygone blanc dessiné sur un fond rouge
///////////////////////////////////////////////////////////////////////////////  
#include <stdio.h>      
#include <stdlib.h>     
#include <math.h>
#include <string>
#include "glad/glad.h"
#include "headers/Point.h"
#include "headers/Vector.h"
#include "headers/Voxel.h"

#include <fstream>

#include <vector>
#include <iostream>
#include <iomanip>

/* Dans les salles de TP, vous avez généralement accès aux glut dans C:\Dev. Si ce n'est pas le cas, téléchargez les .h .lib ...
Vous pouvez ensuite y faire référence en spécifiant le chemin dans visual. Vous utiliserez alors #include <glut.h>. 
Si vous mettez glut dans le répertoire courant, on aura alors #include "glut.h" 
*/

#include <GL/glut.h>

// Définition de la taille de la fenêtre
#define WIDTH  480

#define HEIGHT 480

// Définition de la couleur de la fenêtre
#define RED   1
#define GREEN 0
#define BLUE  0
#define ALPHA 1


// Touche echap (Esc) permet de sortir du programme
#define KEY_ESC 27


// Entêtes de fonctions
void init_scene();
void render_scene();
GLvoid initGL();
GLvoid window_display();
GLvoid window_reshape(GLsizei width, GLsizei height); 
GLvoid window_key(unsigned char key, int x, int y); 

// angle of rotation for the camera direction
float angle = 0.0f;
// actual vector representing the camera's direction
float lx=-1.0f,lz=-1.0f;
// XZ position of the camera
float x=1.0f, z=1.0f;
// the key states. These variables will be zero
//when no key is being presses
float deltaAngle = 0.0f;
float deltaMove = 0;
int xOrigin = -1;

int main(int argc, char **argv) 
{  

  std::ifstream fichier("triceratops.off", std::ios::in);
  int nbPoints, nbPolys, nbEdges;
  long double x = 0;
  std::string chaine1, chaine2;
  std::vector<double>* coord  = new std::vector<double>();

  if(fichier)
  {
    fichier >> chaine1;/* >> entier1 >> entier2;*/  /*on lit jusqu'à l'espace et on stocke ce qui est lu dans la variable indiquée */
    if(chaine1 == "OFF")
    {
      std::cout << "Ouverture fichier OFF" << std::endl;
      fichier >> nbPoints >> nbPolys >> nbEdges;
      std::cout << "nbPoints = " <<nbPoints<<", nbPolys = "<<nbPolys<<", nbEdges = "<<nbEdges<<std::endl;
      int i = 0;
      while(i<nbPoints*3)
      {
        fichier>> x;
        coord->push_back(x);
        i++;
      }
      std::cout <<"dernier x "<<std::setprecision (9)<< x<<std::endl;
    }
    fichier.close();
  }
  else
    std::cerr << "Impossible d'ouvrir le fichier !" << std::endl;

   std::ofstream fichier2("test.txt", std::ios::out | std::ios::trunc);  // ouverture en écriture avec effacement du fichier ouvert
 
  // initialisation  des paramètres de GLUT en fonction
  // des arguments sur la ligne de commande
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_RGBA);

  // définition et création de la fenêtre graphique, ainsi que son titre
  glutInitWindowSize(WIDTH, HEIGHT);
  glutInitWindowPosition(0, 0);
  glutCreateWindow("Premier exemple : carré");


  if(!gladLoadGL()) {
    printf("Something went wrong!\n");
    exit(-1);
  }



  // initialisation de OpenGL et de la scène
  initGL();  
  init_scene();

  // choix des procédures de callback pour 
  // le tracé graphique
  glutDisplayFunc(&window_display);
  // le redimensionnement de la fenêtre
  glutReshapeFunc(&window_reshape);
  // la gestion des événements clavier
  glutKeyboardFunc(&window_key);

  // la boucle prinicipale de gestion des événements utilisateur
  glutMainLoop(); 

  return 1;
}

// initialisation du fond de la fenêtre graphique : noir opaque
GLvoid initGL() 
{
  glClearColor(0, 0, 0, ALPHA);        
}

// Initialisation de la scene. Peut servir à stocker des variables de votre programme
// à initialiser
void init_scene()
{
}

// fonction de call-back pour l´affichage dans la fenêtre

GLvoid window_display()
{
  glClear(GL_COLOR_BUFFER_BIT);
  glLoadIdentity();

  // C'est l'endroit où l'on peut dessiner. On peut aussi faire appel
  // à une fonction (render_scene() ici) qui contient les informations 
  // que l'on veut dessiner
  render_scene();

  // trace la scène grapnique qui vient juste d'être définie
  glFlush();
}

// fonction de call-back pour le redimensionnement de la fenêtre

GLvoid window_reshape(GLsizei width, GLsizei height)
{  
  glViewport(0, 0, width, height);

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  // ici, vous verrez pendant le cours sur les projections qu'en modifiant les valeurs, il est
  // possible de changer la taille de l'objet dans la fenêtre. Augmentez ces valeurs si l'objet est 
  // de trop grosse taille par rapport à la fenêtre.
  glOrtho(-2.0, 2.0, -2.0, 2.0, -2.0, 2.0);

  // toutes les transformations suivantes s´appliquent au modèle de vue 
  glMatrixMode(GL_MODELVIEW);
}

// fonction de call-back pour la gestion des événements clavier

void mouseMove(int x, int y) {

  // this will only be true when the left button is down
  if (xOrigin >= 0) {

    // update deltaAngle
    deltaAngle = (x - xOrigin) * 0.001f;

    // update camera's direction
    lx = sin(angle + deltaAngle);
    lz = -cos(angle + deltaAngle);
  }
}


GLvoid window_key(unsigned char key, int x, int y) 
{  
  float fraction = 0.1f;
  switch (key) {    
  case KEY_ESC:  
    exit(1);                    
    break;
  case 113: 
    std::cout<<"touche gauche "<<std::endl;
    angle -= 0.01f;
    lx = sin(angle);
    lz = -cos(angle);
    break;
  case 100 :
    std::cout<<"touche droite "<<std::endl;
    angle += 0.01f;
    lx = sin(angle);
    lz = -cos(angle);
    break; 

  case 122 :
    x += lx * fraction;
    z += lz * fraction;
    break;
  case 115 :
    x -= lx * fraction;
    z -= lz * fraction;
    break;
  default:
    printf ("La touche %d n´est pas active.\n", key);
    break;
  }
   glutPostRedisplay();
}


/*void drawLine(Point *p, Vector *v) {

	glColor3b(0,  0,  255);
	glVertex3f(p->getX(),p->getY(),p->getZ());	
	glVertex3f(v->getX(),v->getY(),v->getZ());

}*/
void text(double x, double y, std::string menu)
{
    int len = 80;
    len = menu.length();
    glColor3f(1,1,1);

    glMatrixMode( GL_PROJECTION );
    glPushMatrix();
    glLoadIdentity();

    gluOrtho2D( 0, 600, 0, 600 );

    glMatrixMode( GL_MODELVIEW );
    glPushMatrix();

    glLoadIdentity();

    glRasterPos2i(265, 300);


    for ( int i = 0; i < len; ++i )
    {
        glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, menu[i]);
    }

    glPopMatrix();

    glMatrixMode( GL_PROJECTION );
    glPopMatrix();
    glMatrixMode( GL_MODELVIEW );
}
void traceSegment(Point *A, Point *B,Vector color) {
  glColor3f(color.getX(),color.getY(),color.getZ());
  glBegin(GL_LINES);
      glVertex3f(A->getX(),A->getY(),A->getZ());
      glVertex3f(B->getX(),B->getY(),B->getZ());
    glEnd();
}

void tracePoint(Point *A,Vector color) {
  glColor3f(color.getX(),color.getY(),color.getZ());
  glBegin(GL_POINTS);
    glVertex3f(A->getX(),A->getY(),A->getZ());
    glEnd();
}

void traceVector(Vector *v,Vector color) {
  glColor3f(color.getX(),color.getY(),color.getZ());
  glBegin(GL_LINES);
      glVertex3f(0,0,0);
      glVertex3f(v->getX(),v->getY(),v->getZ());
    glEnd();
}

void traceQuad(Point* A, Point* B,Point* C,Point* D, Vector color) {
  glColor3f(color.getX(),color.getY(),color.getZ());
  glBegin(GL_QUADS);
    glVertex3f(A->getX(),A->getY(),A->getZ());
    glVertex3f(B->getX(),B->getY(),B->getZ());
    glVertex3f(C->getX(),C->getY(),C->getZ());
    glVertex3f(D->getX(),D->getY(),D->getZ());
  glEnd();
}

void DrawCurve(std::vector<Point> *TabPointsOfCurve) {
  glBegin(GL_LINE_STRIP);
  for(long i = 0; i < TabPointsOfCurve->size(); i++)
  {
    glVertex3f((TabPointsOfCurve->at(i)).getX(), (TabPointsOfCurve->at(i)).getY(),(TabPointsOfCurve->at(i)).getZ());
  }
  glEnd();
}

std::vector<Point>* HermiteCubicCurve(Point* P0, Point* P1, Vector* V0, Vector* V1, long nbU) {
  std::vector<Point>* tab = new  std::vector<Point>() ;
  for(long i = 1; i < nbU; i++)
  {
    double u = (double)i/nbU;
    double F1 = 2*pow(u,3) - 3*pow(u,2) + 1;
    double F2 = - 2*pow(u,3) + 3*pow(u,2);
    double F3 = pow(u,3) - 2*pow(u,2) + u;
    double F4 = pow(u,3) - pow(u,2);

    Point* p = new Point(
                          F1*P0->getX()+F2*P1->getX()+F3*V0->getX()+F4*V1->getX(),
                          F1*P0->getY()+F2*P1->getY()+F3*V0->getY()+F4*V1->getY(),
                          F1*P0->getZ()+F2*P1->getZ()+F3*V0->getZ()+F4*V1->getZ());
    tab->push_back(p);
  }
  return tab;
}

long fact (long x) 
{ 
  if ((x == 1) ||(x==0)) 
    return 1; 
  return (x * fact(x-1)); 
} 

std::vector<Point>* bezierCurveByBernstein(std::vector<Point>* TabControlPoint, long nbU) {
  std::vector<Point>* tab = new  std::vector<Point>();
  long n = TabControlPoint->size()-1;
  long double sommePolyBX, sommePolyBY, sommePolyBZ,  u;
  long double B=0;

  for(long i = 0; i < nbU-1; i++)
  {
    u = (double)i/(double)(nbU-1);
    sommePolyBX = 0;
    sommePolyBY = 0; 
    sommePolyBZ = 0; 
    B=0;

    for(long j = 0; j <= n; j++)
    {
      B = (long double) (fact(n)* pow(u, j) * pow(1 - u, n - j)) / (fact(n - j) * fact(j));

      sommePolyBX += B * TabControlPoint->at(j).getX();
      sommePolyBY += B * TabControlPoint->at(j).getY();
      sommePolyBZ += B * TabControlPoint->at(j).getZ();
    }

    tab->push_back(new Point(sommePolyBX, sommePolyBY, sommePolyBZ));
  }
  return tab;
}

Point* Approximate(double t, Point* pt1, Point* pt2)
{
    double x = pt1->getX() * (1-t) + pt2->getX()* t;
    double y = pt1->getY() * (1-t) + pt2->getY() * t;

    return new Point(x, y, 0);
}


std::vector<Point>* BezierCurveByCasteljau(std::vector<Point>* TabControlPoint, long nbU) {
  std::vector<Point>* bezierPoints = new  std::vector<Point>();
  long n = TabControlPoint->size()-1;
  double p = (double)(1.0/(double)nbU);
  for(double t=0; t<1; t=t+p)
    {
    std::vector<Point>* temp1 = new  std::vector<Point>();
    temp1= TabControlPoint;

    while(temp1->size()>1)
    {
      std::vector<Point>* temp2 = new  std::vector<Point>();
      glBegin(GL_LINE_STRIP);
      for(int i = 0 ; i<temp1->size()-1 ; i++)
      {
          Point* pt1 = new Point(temp1->at(i).getX(),temp1->at(i).getY(),0);
          Point* pt2 = new Point(temp1->at(i+1).getX(),temp1->at(i+1).getY(),0);
          temp2->push_back(Approximate(t, pt1, pt2));
          // tracePoint(&temp2->at(i),Vector(0,0,255));
          //glColor3f(0.0,1.0,0.0);
          //glVertex3f((temp2->at(i)).getX(), (temp2->at(i)).getY(),(temp2->at(i)).getZ());
      }
      glEnd();
      temp1 = temp2;
    }
    bezierPoints->push_back(temp1->at(0));
  }
  return bezierPoints;
}



std::vector<Point>* surfaceCylindrique(std::vector<Point>* courbeBezier, Vector* droite, int nbU, int nbV) {

  int pas_incr = courbeBezier->size()/(nbV-1);
  int nb_pt_bezier = courbeBezier->size();
  int pas = 0, pas2=pas_incr, p=0;

  std::vector<Point> tab; 
  std::vector<Point> tabTemp; 
  std::vector<Point> tabV[nb_pt_bezier]; 
  std::vector<Point>* tabVret; 

  for(int i=0; i<nbU; i++)
  {
    tab.clear();
    for(int j=0; j<nb_pt_bezier; j++)
    {
      Point P(courbeBezier->at(j).getX()+i*droite->getX(),
              courbeBezier->at(j).getY()+i*droite->getY(),
              courbeBezier->at(j).getZ()+i*droite->getZ());
      tab.push_back(&P);

      if(j == pas)
      {
        tabV[p].push_back(&P);
        p++;
        pas+=pas_incr;
      }
    }
    DrawCurve(&tab);
    p=0;
    pas = 0;
  }
  //return tabV;
 // int nb_pt_bezier = tabV->size();

  glColor3f(1.0,1.0,0.0); // YELLOW
  int j = 0;
  //std::vector<Point> tabTemp; 
  for(int i=0; i<nb_pt_bezier; i++)
  {
    tabTemp.clear();
    while(!tabV[i].empty())
    {
      tabTemp.push_back(tabV[i].back());
     // tabVret[i].push_back(tabV[i].back());
      tabV[i].pop_back();
    }
    DrawCurve(&tabTemp);
  }
  //return tabVret;
}

  // Trace les courbes iso-paramétriques
void trace_surface_cylindrique(std::vector<Point>* tabV) {
;
}

void surfaceReglee(std::vector<Point>* courbe1, std::vector<Point>* courbe2,  int nbU, int nbV) {

  // *** INITIALISATION ***
  std::vector<Point> tabV[nbV]; 
  int nbPoints = courbe1->size()/nbU;
  std::vector<Point>* tabTemp2  = new std::vector<Point>();
  std::vector<Point>* tabTemp3  = new std::vector<Point>();

  glColor3f(1.0,1.0,0.0); // YELLOW
  int j = 0;
  //std::vector<Point> tabTemp; 
  tabTemp2->push_back(courbe1->at(0));
  tabTemp2->push_back(courbe2->at(0));

  Vector* v = new Vector(courbe2->at(0).getX() - courbe1->at(0).getX(),
                          courbe2->at(0).getY() - courbe1->at(0).getY(),
                          courbe2->at(0).getZ() - courbe1->at(0).getZ());

  Point* p2 = new Point(courbe1->at(0).getX()+0.0*v->getX(),
                         courbe1->at(0).getY()+0.0*v->getY(),
                         courbe1->at(0).getZ()+0.0*v->getZ());

  std::vector<Point>* courbePortion = new std::vector<Point>();

  // Trace les deux courbes 
  glColor3f(0.0, 1.0, 0.0); // GREEN
  DrawCurve(courbe1);
  glColor3f(0.0, 0.0, 1.0); // BLUE
  DrawCurve(courbe2);



  // Parcours d'une des deux courbe
  for(int i=0; i<  courbe1->size(); i=i+(courbe1->size()/nbU))
  {
    tabTemp3->push_back(courbe1->at(i));
    tabTemp3->push_back(courbe2->at(i));

    v = new Vector(courbe2->at(i).getX() - courbe1->at(i).getX(),
                          courbe2->at(i).getY() - courbe1->at(i).getY(),
                          courbe2->at(i).getZ() - courbe1->at(i).getZ());


    // Trace les portions de segment entre deux droites
    double n = 0.0;
    if( i<  (courbe1->size()-(courbe1->size()/nbU)))
    {
      Vector* v2 = new Vector(courbe2->at(i+(courbe1->size()/nbU)).getX() - courbe1->at(i+(courbe1->size()/nbU)).getX(),
                            courbe2->at(i+(courbe1->size()/nbU)).getY() - courbe1->at(i+(courbe1->size()/nbU)).getY(),
                            courbe2->at(i+(courbe1->size()/nbU)).getZ() - courbe1->at(i+(courbe1->size()/nbU)).getZ());
      for (int j = 1 ; j< nbV; j++)
        {
          n = n + (double)(1.0/nbV);
          Point* p1 = new Point(courbe1->at(i).getX()+n*v->getX(),
                                courbe1->at(i).getY()+n*v->getY(),
                                courbe1->at(i).getZ()+n*v->getZ());

          tabV[j].push_back(p1);

          Point* p2 = new Point(courbe1->at(i+(courbe1->size()/nbU)).getX()+n*v2->getX(),
                                courbe1->at(i+(courbe1->size()/nbU)).getY()+n*v2->getY(),
                                courbe1->at(i+(courbe1->size()/nbU)).getZ()+n*v2->getZ());

          tracePoint(p1,Vector(255,255,0));
          courbePortion->clear();
          courbePortion->push_back(p1);
          courbePortion->push_back(p2);
          glColor3f(1.0,0.0,0.0); // RED
          DrawCurve(courbePortion);
        }
      }

    tabTemp2->clear();
    tabTemp2->push_back(courbe1->at(i));
    tabTemp2->push_back(courbe2->at(i));
    glColor3f(1.0,1.0,0.0); // YELLOW
    DrawCurve(tabTemp2);
  }
}

void BezierSurfaceByCasteljau(std::vector<Point>* TabControlPointU, int nbControlPointU, int nbU, 
                                 std::vector<Point>* TabControlPointV, int nbControlPointV, int nbV) {

  std::vector<Point>* Tab1 = new std::vector<Point>();
  std::vector<Point>* Tab2 = new std::vector<Point>();
  Tab1 = BezierCurveByCasteljau(TabControlPointU, nbControlPointU);
  Tab2 = BezierCurveByCasteljau(TabControlPointV, nbControlPointV);
  surfaceReglee(Tab1, Tab2, nbU, nbV);
}


void displayVoxelRec(Voxel* v, Point* ct, double ray,double reso, double i) {

  if(i<reso)
  {
    for(int k=0; k<8; k++)
    {
      Voxel* vtemp = new Voxel(&v->getSubCenterPoints()->at(k),(double)v->getLength()/2.0);
      int test = vtemp->isInsideSphere(ct, ray);
      //std::cout<<"test ="<<test<<std::endl;
      if(test!=2)
      {
        if(test == 0)
          vtemp->displayV();
        else
          ;//displayVoxelRec(vtemp, ct,  ray, reso, i+1);
        //std::cout<<"i = "<<i<<" et le sous-voxel "<<k<<" est dans la sphere, reso = "<<reso<<std::endl;
      }
      else // test == 2
      {
        if(i == reso-1)
          vtemp->displayV();
        else 
          displayVoxelRec(vtemp, ct,  ray, reso, i+1);
      }
    }
  }
}


void displaySphereAdaptatif(Point* ct, double ray, double reso) { // Point center, double rayon, double resolution
    Voxel* v = new Voxel(ct,ray+ray*0.5);
    //v->displayV();
    displayVoxelRec(v, ct, ray, reso, 0);
}


//////////////////////////////////////////////////////////////////////////////////////////
// Fonction que vous allez modifier afin de dessiner
/////////////////////////////////////////////////////////////////////////////////////////

void render_scene()
{

  // Clear Color and Depth Buffers
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Reset transformations
  glLoadIdentity();

    // Set the camera
  gluLookAt(  x, 1.0f, z,
      x+lx, 0.0f,  z+lz,
      0.0f, 0.0f,  1.0f);


   //  const GLfloat LightPos[4] = {0,0,3,1};
   //  
   //  glClearColor(0.0 , 0.0 , 0.0 , 0.0);

/*  glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    GLfloat ambient[] = {0.2 , 0.2 , 0.2 , 1.0};
    GLfloat diffuse[] =  {0.8 , 0.8 , 0.8 , 1.0};
    GLfloat position[] = {1.0 , 1.0 , 1.0 , 1.0};
    glLightfv(GL_LIGHT0 , GL_AMBIENT , ambient);
    glLightfv(GL_LIGHT0 , GL_DIFFUSE , diffuse);
    glLightfv(GL_LIGHT0 , GL_POSITION , position);
glShadeModel (GL_SMOOTH);
  GLfloat lightpos[] = {0.75 ,0.0, 1.0, 1.0};
  glLightfv(GL_LIGHT0, GL_POSITION, lightpos);*/

  glPointSize(3);
  glColor3f(1.0, 0.0, 0.0); // RED

  //gluLookAt(2,1,1,0,0,0,0,0,1);
  //displaySphereAdaptatif(new Point(0,0,0), 1.0, 7.0);


GLfloat vertices[] = {0.1,0.2,0.3,
                      0.5,0.2,0.5,
                      0.1,0.1,0.3,
                      0.2,0.4,0.3,
                      0.1,0.2,0.3,
                      0.8,0.2,0.3,
                      0.1,0.7,0.3,
                      0.3,0.2,0.6};          // 8 of vertex coords
GLubyte indices[] = {0,1,2, 2,3,0,   // first half (18 indices)
                     0,3,4, 4,5,0,
                     0,5,6, 6,1,0,

                     1,6,7, 7,2,1,   // second half (18 indices)
                     7,4,3, 3,2,7,
                     4,7,6, 6,5,4};

// activate and specify pointer to vertex array
glEnableClientState(GL_VERTEX_ARRAY);
glVertexPointer(3, GL_FLOAT, 0, vertices);

// draw first half, range is 6 - 0 + 1 = 7 vertices used
glDrawRangeElements(GL_TRIANGLES, 0, 6, 18, GL_UNSIGNED_BYTE, indices);

// draw second half, range is 7 - 1 + 1 = 7 vertices used
glDrawRangeElements(GL_TRIANGLES, 1, 7, 18, GL_UNSIGNED_BYTE, indices+18);

// deactivate vertex arrays after drawing
glDisableClientState(GL_VERTEX_ARRAY);



  
  glutSwapBuffers();
}


