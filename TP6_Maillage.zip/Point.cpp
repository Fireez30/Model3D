#include "headers/Point.h"
#include "headers/Vector.h"

// Constructors 
Point::Point() {}

Point::~Point() {}

Point::Point(double x,double y, double z) {
	this->x = x;
	this->y = y;
	this->z = z;
}

Point::Point(Point *p) {
	this->x = p->getX();
	this->y = p->getY();
	this->z = p->getZ();
}


// getters
double Point::getX() {
	return this->x;
}
double Point::getY() {
	return this->y;
}
double Point::getZ() {
	return this->z;
}

//setters
void Point::setX(double x) {
	this->x = x;
}
void Point::setY(double y) {
	this->y = y;
}
void Point::setZ(double z) {
	this->z = z;
}

// Point methods

Vector* Point::createVector(Point *A, Point *B) {
	Vector *v = new Vector();
	v->setX(B->getX() - A->getX());
	v->setY(B->getY() - A->getY());
	v->setZ(B->getZ() - A->getZ());
	return v;
}


Point* Point::projectOnLine(Point *B, Point *C) {

	Vector *BA = new Vector(x - B->getX(), 
							y - B->getY(), 
							z - B->getZ());

	Vector *BC = new Vector(C->getX() - B->getX(), 
							C->getY() - B->getY(), 
							C->getZ() - B->getZ());

/*	BA->normalize(); */
	BC->normalize();

	double normeBAprime = BA->scalar(BC) / BC->norme();

	Point* Aprime = new Point(
								B->getX() + BC->getX()*normeBAprime, 
							 	B->getY() + BC->getY()*normeBAprime, 
							  	B->getZ() + BC->getZ()*normeBAprime);
    return Aprime;
}


Point* Point::projectOnLine (Vector *v, Point *PLine) {

	Vector *BA = new Vector(x - PLine->getX(), 
							y - PLine->getY(), 
							z - PLine->getZ());

	v->normalize();
	double normeBAprime = v->scalar(BA) / v->norme();

	Point* Aprime = new Point(
								PLine->getX() + v->getX()*normeBAprime, 
							 	PLine->getY() + v->getY()*normeBAprime, 
							  	PLine->getZ() + v->getZ()*normeBAprime);
    return Aprime;
}

Point* Point::projectOnLine(Point *A, Vector *n) {
	
	Vector* MA = new Vector(A->getX() - x,
						   A->getY() - y,
						   A->getZ() - z);
	n->normalize();

	double normeMMprime = MA->scalar(n) / n->norme();

	Point* Mprime = new Point(
								x - n->getX()*normeMMprime, 
							 	y - n->getY()*normeMMprime, 
							  	z - n->getZ()*normeMMprime);
    return Mprime;
}
 
std::string Point::print() {
	return "("+std::to_string(x)+","+std::to_string(y)+","+std::to_string(z)+")";
}

int Point::isInsideSphere(Point* ct, double ray) { // return 0 if P inside Sphere, else return 1
  Vector* v = new Vector(this->getX() - ct->getX(),
                         this->getY() - ct->getY(),
                         this->getZ() - ct->getZ());
  if(v->norme()<ray)
    return 0;
  else
    return 1;
}