  
#include <math.h>

#include "headers/Vector.h"

// Constructors 
Vector::Vector() {}
Vector::~Vector() {}
Vector::Vector(double x,double y, double z) {
	this->x = x;
	this->y = y;
	this->z = z;
}
Vector::Vector(Vector *p) {
	x = p->getX();
	y = p->getY();
	z = p->getZ();
}

// getters
double Vector::getX() {
	return x;
}
double Vector::getY() {
	return y;
}
double Vector::getZ() {
	return z;
}

//setters
void Vector::setX(double x) {
	this->x = x;
}
void Vector::setY(double y) {
	this->y = y;
}
void Vector::setZ(double z) {
	this->z = z;
}

// Vector methods

double Vector::norme() {
	return sqrt(x*x + y*y + z*z);
}

void Vector::normalize() {
	double n = norme();
	x /= n;
	y /= n;
	z /= n;
}


double Vector::scalar(Vector *vector2) {
	return x*vector2->getX() + y*vector2->getY() + z*vector2->getZ();
}


Vector Vector::Vectoriel( Vector *vector2) {
	Vector v = new Vector();
	v.setX(y * vector2->getZ() - z * vector2->getY());
	v.setY(z * vector2->getX() - x * vector2->getZ());
	v.setZ(x * vector2->getY() - y * vector2->getX());
	return v;
}

double Vector::Angle(Vector *vector2) {
	return acos(scalar(vector2) / (this->norme()*vector2->norme()));
}



